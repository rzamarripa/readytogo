(function(){Movimientos = new Mongo.Collection("movimientos");
Movimientos.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbHMvbW92aWVudG9zLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFdBQVcsR0FBUyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDeEQsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUNoQixRQUFNLEVBQUUsa0JBQVk7QUFBRSxXQUFPLElBQUksQ0FBQztHQUFFO0FBQ3BDLFFBQU0sRUFBRSxrQkFBWTtBQUFFLFdBQU8sSUFBSSxDQUFDO0dBQUU7QUFDcEMsUUFBTSxFQUFFLGtCQUFZO0FBQUUsV0FBTyxJQUFJLENBQUM7R0FBRTtDQUNyQyxDQUFDLENBQUMiLCJmaWxlIjoiL21vZGVscy9tb3ZpZW50b3MuanMiLCJzb3VyY2VzQ29udGVudCI6WyJNb3ZpbWllbnRvcyBcdFx0XHRcdFx0XHQ9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwibW92aW1pZW50b3NcIik7XG5Nb3ZpbWllbnRvcy5hbGxvdyh7XG4gIGluc2VydDogZnVuY3Rpb24gKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgdXBkYXRlOiBmdW5jdGlvbiAoKSB7IHJldHVybiB0cnVlOyB9LFxuICByZW1vdmU6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRydWU7IH1cbn0pOyJdfQ==
}).call(this);

//# sourceMappingURL=movientos.js.map
