(function(){
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiIvc2VydmVyL25ld3MuanMiLCJzb3VyY2VzQ29udGVudCI6W119
}).call(this);

//# sourceMappingURL=news.js.map
