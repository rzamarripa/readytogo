/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Date = Package['es5-shim'].Date;
parseInt = Package['es5-shim'].parseInt;
moment = Package['momentjs:moment'].moment;
check = Package.check.check;
Match = Package.check.Match;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
MeteorCamera = Package['mdg:camera'].MeteorCamera;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
CryptoJS = Package['jparker:crypto-core'].CryptoJS;
Accounts = Package['accounts-base'].Accounts;
AccountsServer = Package['accounts-base'].AccountsServer;
Autoupdate = Package.autoupdate.Autoupdate;

