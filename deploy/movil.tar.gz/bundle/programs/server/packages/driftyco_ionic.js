(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['driftyco:ionic'] = {};

})();

//# sourceMappingURL=driftyco_ionic.js.map
