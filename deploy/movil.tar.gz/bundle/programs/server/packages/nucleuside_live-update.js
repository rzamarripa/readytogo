(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var SpacebarsCompiler = Package['spacebars-compiler'].SpacebarsCompiler;
var Autoupdate = Package.autoupdate.Autoupdate;
var _ = Package.underscore._;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var HTML = Package.htmljs.HTML;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/nucleuside_live-update/packages/nucleuside_live-update.j //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nucleuside:live-update'] = {};

})();

//# sourceMappingURL=nucleuside_live-update.js.map
