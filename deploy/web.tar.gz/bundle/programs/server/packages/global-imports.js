/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
Roles = Package['alanning:roles'].Roles;
moment = Package['momentjs:moment'].moment;
MeteorCamera = Package['mdg:camera'].MeteorCamera;
Counts = Package['tmeasday:publish-counts'].Counts;
publishCount = Package['tmeasday:publish-counts'].publishCount;
XLSX = Package['ricklupton:xlsx'].XLSX;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Accounts = Package['accounts-base'].Accounts;
Autoupdate = Package.autoupdate.Autoupdate;

