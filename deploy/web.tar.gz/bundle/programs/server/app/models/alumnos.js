(function(){Alumnos = new Mongo.Collection("alumnos");
Alumnos.allow({
  insert: function insert() {
    return true;
  },
  update: function update() {
    return true;
  },
  remove: function remove() {
    return true;
  }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbHMvYWx1bW5vcy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEdBQVMsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2hELE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDWixRQUFNLEVBQUUsa0JBQVk7QUFBRSxXQUFPLElBQUksQ0FBQztHQUFFO0FBQ3BDLFFBQU0sRUFBRSxrQkFBWTtBQUFFLFdBQU8sSUFBSSxDQUFDO0dBQUU7QUFDcEMsUUFBTSxFQUFFLGtCQUFZO0FBQUUsV0FBTyxJQUFJLENBQUM7R0FBRTtDQUNyQyxDQUFDLENBQUMiLCJmaWxlIjoiL21vZGVscy9hbHVtbm9zLmpzIiwic291cmNlc0NvbnRlbnQiOlsiQWx1bW5vcyBcdFx0XHRcdFx0XHQ9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiYWx1bW5vc1wiKTtcbkFsdW1ub3MuYWxsb3coe1xuICBpbnNlcnQ6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRydWU7IH0sXG4gIHVwZGF0ZTogZnVuY3Rpb24gKCkgeyByZXR1cm4gdHJ1ZTsgfSxcbiAgcmVtb3ZlOiBmdW5jdGlvbiAoKSB7IHJldHVybiB0cnVlOyB9XG59KTsiXX0=
}).call(this);
